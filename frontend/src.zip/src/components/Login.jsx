import React, { useState } from 'react';
import API from '../api/axios';

const Login = ({ onLoginSuccess, onSwitchToRegister }) => {
  const [role, setRole] = useState('CUSTOMER'); // Visual tab state ('CUSTOMER' or 'ADMIN')
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      // Both Customer and Admin use the exact same login endpoint
      const response = await API.post('/auth/login', {
        email: email,
        password: password,
      });

      const { token, fullName, role: userRole } = response.data;
      
      localStorage.setItem('token', token);
      localStorage.setItem('userRole', userRole || role);
      if (fullName) {
        localStorage.setItem('fullName', fullName);
      }

      setLoading(false);
      onLoginSuccess(userRole || role);
    } catch (err) {
      console.error('Login error:', err);
      setError(
        err.response?.data?.message || 'Invalid email or password. Please try again.'
      );
      setLoading(false);
    }
  };

  return (
    <div style={styles.container}>
      <div style={styles.card}>
        <div style={styles.header}>
          <h2 style={styles.brand}>🏦 BankFlow</h2>
          <p style={styles.subtitle}>Sign in to your account</p>
        </div>

        {/* Role Selection Tabs */}
        <div style={styles.roleTabs}>
          <button
            type="button"
            style={{
              ...styles.roleTabBtn,
              backgroundColor: role === 'CUSTOMER' ? '#0d6360' : '#f3f4f6',
              color: role === 'CUSTOMER' ? '#ffffff' : '#4b5563',
            }}
            onClick={() => setRole('CUSTOMER')}
          >
            👤 Customer Login
          </button>
          <button
            type="button"
            style={{
              ...styles.roleTabBtn,
              backgroundColor: role === 'ADMIN' ? '#0d6360' : '#f3f4f6',
              color: role === 'ADMIN' ? '#ffffff' : '#4b5563',
            }}
            onClick={() => setRole('ADMIN')}
          >
            🛡️ Admin Login
          </button>
        </div>

        {error && <div style={styles.errorBox}>⚠️ {error}</div>}

        <form onSubmit={handleLogin} style={styles.form}>
          <div style={styles.field}>
            <label style={styles.label}>Email Address</label>
            <input
              type="email"
              placeholder="e.g. name@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              style={styles.input}
            />
          </div>

          <div style={styles.field}>
            <label style={styles.label}>Password</label>
            <input
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={styles.input}
            />
          </div>

          <button type="submit" disabled={loading} style={styles.submitBtn}>
            {loading ? 'Signing in...' : `Sign In as ${role === 'ADMIN' ? 'Admin' : 'Customer'}`}
          </button>
        </form>

        {/* Register Prompt */}
        <div style={styles.footerPrompt}>
          <span>Don't have an account?</span>
          <button type="button" onClick={onSwitchToRegister} style={styles.linkBtn}>
            Register here
          </button>
        </div>
      </div>
    </div>
  );
};

const styles = {
  container: { display: 'flex', minHeight: '100vh', alignItems: 'center', justifyContent: 'center', backgroundColor: '#f9fafb', padding: '16px' },
  card: { backgroundColor: '#ffffff', borderRadius: '16px', padding: '32px', width: '100%', maxWidth: '420px', border: '1px solid #eef0ec', boxShadow: '0 4px 12px rgba(0,0,0,0.03)' },
  header: { textAlign: 'center', marginBottom: '24px' },
  brand: { fontSize: '24px', fontWeight: '800', fontFamily: 'Georgia, serif', color: '#0d6360', margin: '0 0 6px 0' },
  subtitle: { fontSize: '14px', color: '#6b7280', margin: 0 },
  roleTabs: { display: 'flex', gap: '8px', marginBottom: '20px', backgroundColor: '#f3f4f6', padding: '4px', borderRadius: '10px' },
  roleTabBtn: { flex: 1, border: 'none', padding: '10px', borderRadius: '8px', fontWeight: '700', fontSize: '13px', cursor: 'pointer', transition: 'all 0.2s' },
  form: { display: 'flex', flexDirection: 'column', gap: '16px' },
  field: { display: 'flex', flexDirection: 'column', gap: '6px' },
  label: { fontSize: '13px', fontWeight: '700', color: '#374151' },
  input: { padding: '11px 14px', borderRadius: '8px', border: '1px solid #d1d5db', fontSize: '14px', outline: 'none' },
  submitBtn: { backgroundColor: '#0d6360', color: '#ffffff', border: 'none', padding: '12px', borderRadius: '8px', fontWeight: '700', fontSize: '14px', cursor: 'pointer', marginTop: '4px' },
  errorBox: { backgroundColor: '#fee2e2', color: '#991b1b', padding: '10px 14px', borderRadius: '8px', fontSize: '13px', marginBottom: '16px' },
  footerPrompt: { display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '6px', marginTop: '20px', fontSize: '13px', color: '#6b7280' },
  linkBtn: { background: 'none', border: 'none', color: '#0d6360', fontWeight: '700', cursor: 'pointer', padding: 0, fontSize: '13px' },
};

export default Login;
